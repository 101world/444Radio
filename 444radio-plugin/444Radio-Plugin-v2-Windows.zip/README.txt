444 Radio Plugin v2
====================

Two ways to use 444 Radio:

1. STANDALONE SOFTWARE (no DAW needed)
   - Double-click "444 Radio v2.exe"
   - That's it - runs as its own window

2. VST3 PLUGIN (for DAWs: Ableton, FL Studio, etc.)
   - Copy the "444 Radio v2.vst3" FOLDER to:
     C:\Program Files\Common Files\VST3\
   - Restart your DAW
   - Find "444 Radio v2" in your plugin list

Requirements:
- Windows 10 or later
- Microsoft Edge WebView2 Runtime (usually pre-installed)

Troubleshooting:
- If plugin shows blank/spinning: restart your DAW
- If site won't load: run "ipconfig /flushdns" in Command Prompt

https://444radio.co.in
